package core;

public class MyClass {
public static void main(String[] args){
	System.out.println("My name is Valeriy");
	System.out.println("\u041F\u0440\u0438\u0432\u0435\u0442, Valeriy");}}