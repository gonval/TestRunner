./resources/webdrivers/mac/geckodriver --log fatal $* &> /dev/null
